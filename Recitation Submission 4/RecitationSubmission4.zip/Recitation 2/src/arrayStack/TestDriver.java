package arrayStack;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class TestDriver {

	public static void main(String[] args) throws Exception{
		//
		// INTEGER
		//
		// new stack
		Stack<Integer> intstack = new Stack<>();
		// push six values
		for(int i = 0; i <= 5; i++)
			intstack.push(i);
		// pop 1 value
		System.out.println("Popped " + intstack.pop());
		// display whole stack
		intstack.display();
		// display values 1-3
		intstack.display(1, 3);
		// get value 3
		intstack.search(3);
		// new stack
		Stack<Integer> intcheck = new Stack<>();
		for(int i = 0; i < 2; i++)
			intcheck.push(i);
		// compare with old stack
		System.out.println(intstack.compareTo(intcheck));
		// write stack to temp file
		ObjectOutputStream intout = new ObjectOutputStream(
				new FileOutputStream("inttemp"));
		intout.writeObject(intstack);
		intout.close();
		// read stack from temp
		ObjectInputStream intin = new ObjectInputStream(
				new FileInputStream("inttemp"));
		Stack<Integer> intread = (Stack<Integer>) intin.readObject();
		// display read stack
		intread.display();		
		intin.close();
		
		//
		// CHARACTER
		//
		// new stack
		Stack<Character> charstack = new Stack<>();
		// push five values
		for (char c : "abcde".toCharArray())
			charstack.push(c);
		// pop 1 value
		System.out.println("Popped " + charstack.pop());
		// display whole stack
		charstack.display();
		// display values 1-3
		charstack.display(1, 3);
		// get first value n
		charstack.search('d');
		// new stack
		Stack<Character> charcheck = new Stack<>();
		for(char c : "xyz".toCharArray())
			charcheck.push(c);
		// compare with old stack
		System.out.println(charstack.compareTo(charcheck));
		// write stack to temp file
		ObjectOutputStream charout = new ObjectOutputStream(
				new FileOutputStream("chartemp"));
		charout.writeObject(charstack);
		charout.close();
		// read stack from temp
		ObjectInputStream charin = new ObjectInputStream(
				new FileInputStream("chartemp"));
		Stack<Character> charread = (Stack<Character>) charin.readObject();
		// display read stack
		charread.display();		
		charin.close();
		
		//
		// FLOAT
		//
		// new stack
		Stack<Float> floatstack = new Stack<>();
		// push six values
		for(float i = 0; i <= 2.5; i += 0.5)
			floatstack.push(i);
		// pop 1 value
		System.out.println("Popped " + floatstack.pop());
		// display whole stack
		floatstack.display();
		// display values 1-3
		floatstack.display(1, 3);
		// get value 3
		floatstack.search(1.5f);
		// new stack
		Stack<Float> floatcheck = new Stack<>();
		for(float i = 0; i < 2; i++)
			floatcheck.push(i);
		// compare with old stack
		System.out.println(floatstack.compareTo(floatcheck));
		// write stack to temp file
		ObjectOutputStream floatout = new ObjectOutputStream(
				new FileOutputStream("floattemp"));
		floatout.writeObject(floatstack);
		floatout.close();
		// read stack from temp
		ObjectInputStream floatin = new ObjectInputStream(
				new FileInputStream("floattemp"));
		Stack<Float> floatread = (Stack<Float>) floatin.readObject();
		// display read stack
		floatread.display();		
		floatin.close();
		
		//
		// DOUBLE
		//
		Stack<Double> doublestack = new Stack<>();
		// push six values
		for(double i = 0; i <= 2.5; i += 0.5)
			doublestack.push(i);
		// pop 1 value
		System.out.println("Popped " + doublestack.pop());
		// display whole stack
		doublestack.display();
		// display values 1-3
		doublestack.display(1, 3);
		// get value 3
		doublestack.search(1.5);
		// new stack (haha double check)
		Stack<Double> doublecheck = new Stack<>();
		for(double i = 0; i < 2; i++)
			doublecheck.push(i);
		// compare with old stack
		System.out.println(doublestack.compareTo(doublecheck));
		// write stack to temp file
		ObjectOutputStream doubleout = new ObjectOutputStream(
				new FileOutputStream("doubletemp"));
		doubleout.writeObject(doublestack);
		doubleout.close();
		// read stack from temp
		ObjectInputStream doublein = new ObjectInputStream(
				new FileInputStream("doubletemp"));
		Stack<Double> doubleread = (Stack<Double>) doublein.readObject();
		// display read stack
		doubleread.display();		
		doublein.close();
		
		//
		// String
		//
		Stack<String> stringstack = new Stack<>();
		// push six values
		for(String s : new String[] {"a", "b", "c", "d", "e"})
			stringstack.push(s);
		// pop 1 value
		System.out.println("Popped " + stringstack.pop());
		// display whole stack
		stringstack.display();
		// display values 1-3
		stringstack.display(1, 3);
		// get value 3
		stringstack.search("d");
		// new stack
		Stack<String> stringcheck = new Stack<>();
		for(String s : new String[] {"x", "y", "z"})
			stringcheck.push(s);
		// compare with old stack
		System.out.println(stringstack.compareTo(stringcheck));
		// write stack to temp file
		ObjectOutputStream stringout = new ObjectOutputStream(
				new FileOutputStream("stringtemp"));
		stringout.writeObject(stringstack);
		stringout.close();
		// read stack from temp
		ObjectInputStream stringin = new ObjectInputStream(
				new FileInputStream("stringtemp"));
		Stack<String> stringread = (Stack<String>) stringin.readObject();
		// display read stack
		stringread.display();		
		stringin.close();
	}

}
